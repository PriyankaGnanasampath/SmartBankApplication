package com.smartbank.loan.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartbank.loan.dto.ApplyLoanRequest;
import com.smartbank.loan.dto.ApplyLoanResponse;
import com.smartbank.loan.dto.ApproveLoanRequest;
import com.smartbank.loan.dto.CloseLoanRequest;
import com.smartbank.loan.dto.DisburseLoanRequest;
import com.smartbank.loan.dto.LoanPaymentRequest;
import com.smartbank.loan.model.Loan;
import com.smartbank.loan.model.LoanInstallment;
import com.smartbank.loan.repository.LoanInstallmentRepository;
import com.smartbank.loan.repository.LoanRepository;

@Service
public interface LoanService {
	public ApplyLoanResponse applyLoan(ApplyLoanRequest applyLoanRequest);

	public Loan approveLoan(Long loanId, ApproveLoanRequest approveLoanRequest);

	public Loan rejectLoan(Long loanId, String remarks);

	public Loan disburseLoan(Long loanId, DisburseLoanRequest disburseLoanRequest );

	public Loan payEMI(LoanPaymentRequest loanPaymentRequest);

	public Loan closeLoan(CloseLoanRequest closeLoanRequest);

	public Loan getLoan(String loanNumber);

	public List<Loan> getCustomerLoans(Long customeId);

	public List<Loan> getAllLoans();
}
