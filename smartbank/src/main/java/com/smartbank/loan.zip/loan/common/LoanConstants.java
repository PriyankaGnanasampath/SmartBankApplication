package com.smartbank.loan.common;

import java.math.BigDecimal;

public class LoanConstants {
	public static final String userName = "PRIYA";
	public static final BigDecimal MIN_HOME_LOAN_AMOUNT = BigDecimal.valueOf(5000000);

	public static final BigDecimal MAX_HOME_LOAN_AMOUNT = BigDecimal.valueOf(5000000);

	public static final BigDecimal MIN_PERSONAL_LOAN = BigDecimal.valueOf(5000000);

	public static final BigDecimal MAX_PERSONAL_LOAN = BigDecimal.valueOf(5000000);

	public static final int DEFAULT_HOME_LOAN_RATE = 6;

	public static final int DEFAULT_PERSONAL_LOAN_RATE = 14;

	public static final int DEFAULT_VEHICLE_LOAN_RATE = 8;

	public static final int DEFAULT_GOLD_LOAN_RATE = 15;

	public static final int DEFAULT_EDUCATION_LOAN_RATE = 11;
}
