package com.smartbank.loan.dto;

import java.time.LocalDate;

public class ApproveLoanRequest {
	private double interestRate;

	private String approvedBy;

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	@Override
	public String toString() {
		return "ApproveLoanRequest [interestRate=" + interestRate + ", approvedBy=" + approvedBy + "]";
	}
	
	public ApproveLoanRequest()
	{
		
	}
	
}
