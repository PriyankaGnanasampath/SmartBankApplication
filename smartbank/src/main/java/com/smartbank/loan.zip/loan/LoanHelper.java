package com.smartbank.loan;

import java.util.List;

import org.springframework.stereotype.Component;

import com.smartbank.customer.exception.CustomerNotFoundException;
import com.smartbank.customer.model.Customer;
import com.smartbank.customer.repository.CustomerRepository;
import com.smartbank.loan.exception.InvalidLoanRequestException;
import com.smartbank.loan.model.Loan;
import com.smartbank.loan.model.LoanStatus;
import com.smartbank.loan.model.LoanType;
import com.smartbank.loan.repository.LoanInstallmentRepository;
import com.smartbank.loan.repository.LoanRepository;

@Component
public class LoanHelper {
	private final LoanRepository loanRepository;
	private final LoanInstallmentRepository loanInstallmentRepository;
	private final CustomerRepository customerRepository;

	public LoanHelper(LoanRepository loanRepository, LoanInstallmentRepository loanInstallmentRepository,
			CustomerRepository customerRepository) {
		this.loanRepository = loanRepository;
		this.loanInstallmentRepository = loanInstallmentRepository;
		this.customerRepository = customerRepository;

	}

	public Customer getExistingCustomer(Long customerId) {
		Customer existingCustomer = customerRepository.findById(customerId)
				.orElseThrow(() -> new CustomerNotFoundException("Please provide the valid customerId"));
		return existingCustomer;

	}

	public List<Loan> getExistingLoansForCustomer(Long customerId) {

		List<Loan> existingLoans = loanRepository.findByCustomerCustomerId(customerId);
		return existingLoans;

	}


}
