package com.smartbank.loan.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.smartbank.common.service.SequenceGeneratorService;
import com.smartbank.customer.model.Customer;
import com.smartbank.customer.model.CustomerStatus;
import com.smartbank.customer.repository.CustomerRepository;
import com.smartbank.loan.LoanHelper;
import com.smartbank.loan.common.LoanConstants;
import com.smartbank.loan.dto.ApplyLoanRequest;
import com.smartbank.loan.dto.ApplyLoanResponse;
import com.smartbank.loan.dto.ApproveLoanRequest;
import com.smartbank.loan.dto.CloseLoanRequest;
import com.smartbank.loan.dto.DisburseLoanRequest;
import com.smartbank.loan.dto.LoanPaymentRequest;
import com.smartbank.loan.exception.InvalidLoanRequestException;
import com.smartbank.loan.model.Loan;
import com.smartbank.loan.model.LoanStatus;
import com.smartbank.loan.model.LoanType;
import com.smartbank.loan.repository.LoanInstallmentRepository;
import com.smartbank.loan.repository.LoanRepository;

@Service
public class LoanServiceImpl implements LoanService {
	private final LoanRepository loanRepository;
	private final LoanInstallmentRepository loanInstallmentRepository;
	private final CustomerRepository customerRepository;
	private final LoanHelper loanHelper;
	private final SequenceGeneratorService sequenceGeneratorService;

	public LoanServiceImpl(LoanRepository loanRepository, LoanInstallmentRepository loanInstallmentRepository,
			CustomerRepository customerRepository, LoanHelper loanHelper,
			SequenceGeneratorService sequenceGeneratorService) {
		this.loanRepository = loanRepository;
		this.loanInstallmentRepository = loanInstallmentRepository;
		this.customerRepository = customerRepository;
		this.loanHelper = loanHelper;
		this.sequenceGeneratorService = sequenceGeneratorService;

	}

	@Override
	public ApplyLoanResponse applyLoan(ApplyLoanRequest applyLoanRequest) {
		// TODO Auto-generated method stub
		Loan loan = new Loan();
		Customer existingCustomer = loanHelper.getExistingCustomer(applyLoanRequest.getCustomerId());
		validateApplyLoanRequest(existingCustomer, applyLoanRequest);
		ApplyLoanResponse applyLoanResponse = buildApplyLoanResponse(applyLoanRequest);
		loan.setCreatedBy(applyLoanResponse.getCreatedBy());
		loan.setLoanAmount(applyLoanResponse.getLoanAmount());
		loan.setLoanNumber(applyLoanResponse.getLoanNumber());
		loan.setLoanStatus(applyLoanResponse.getLoanStatus());
		loan.setLoanType(applyLoanResponse.getLoanType());
		loan.setTenureMonths(applyLoanResponse.getTenureMonths());
		loanRepository.save(loan);
		return applyLoanResponse;
	}

	private void validateApplyLoanRequest(Customer existingCustomer, ApplyLoanRequest applyLoanRequest) {
		if (!CustomerStatus.ACTIVE.equals(existingCustomer.getCustomerStatus())) {
			throw new InvalidLoanRequestException("Customer is not an Active Customer.Given Customertatus is`"
					+ existingCustomer.getCustomerStatus());
		}
		Optional<List<Loan>> existingLoans = Optional
				.of(loanHelper.getExistingLoansForCustomer(applyLoanRequest.getCustomerId()));
		if (existingLoans.isPresent()) {
			maximumLoanLimit(existingLoans);
			duplicateLoanRequestCheck(existingLoans, applyLoanRequest.getLoanType());

		}
	}

	private void maximumLoanLimit(Optional<List<Loan>> existingLoans) {
		if ((existingLoans.get().size() > 3)) {
			throw new InvalidLoanRequestException(
					"Customer is already having maximum number of Active Loans. Total Active Loan is"
							+ existingLoans.get().size());
		}
	}

	private void duplicateLoanRequestCheck(Optional<List<Loan>> existingLoans, LoanType loanType) {
		existingLoans.get().stream().forEach(customer -> {

			if (customer.getLoanType().equals(loanType) && customer.getLoanStatus().equals(LoanStatus.ACTIVE)) {
				throw new InvalidLoanRequestException(
						"Customer is already having the Active Loan for this Loan Type. LoanType is " + loanType);
			}
		});
	}

	private ApplyLoanResponse buildApplyLoanResponse(ApplyLoanRequest applyLoanRequest) {
		ApplyLoanResponse applyLoanResponse = new ApplyLoanResponse();
		String loanNummber = sequenceGeneratorService.generateSequenceNumber(applyLoanRequest.getLoanType().toString());
		applyLoanResponse.setCreatedBy(LoanConstants.userName);
		applyLoanResponse.setCreatedDate(LocalDateTime.now());
		applyLoanResponse.setCustomerId(applyLoanRequest.getCustomerId());
		applyLoanResponse.setLoanAmount(applyLoanRequest.getLoanAmount());
		applyLoanResponse.setLoanStatus(LoanStatus.PENDING);
		applyLoanResponse.setLoanNumber(loanNummber);
		applyLoanResponse.setTenureMonths(applyLoanRequest.getTenureMonths());
		return applyLoanResponse;

	}

	@Override
	public Loan approveLoan(Long loanId, ApproveLoanRequest approveLoanRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan rejectLoan(Long loanId, String remarks) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan disburseLoan(Long loanId, DisburseLoanRequest disburseLoanRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan payEMI(LoanPaymentRequest loanPaymentRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan closeLoan(CloseLoanRequest closeLoanRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan getLoan(String loanNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Loan> getCustomerLoans(Long customeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Loan> getAllLoans() {
		// TODO Auto-generated method stub
		return null;
	}
}