package com.smartbank.loan.dto;

public class CloseLoanRequest {
	private String loanNumber;

	public String getLoanNumber() {
		return loanNumber;
	}

	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}

	@Override
	public String toString() {
		return "CloseLoanRequest [loanNumber=" + loanNumber + "]";
	}

	public CloseLoanRequest() {

	}
}
