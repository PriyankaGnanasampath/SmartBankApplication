package com.smartbank.loan.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartbank.loan.model.Loan;
import com.smartbank.loan.model.LoanStatus;
import com.smartbank.loan.model.LoanType;

public interface LoanRepository extends JpaRepository<Loan, Long> {
	public Loan findByLoanNumber(String loanNumber);

	public List<Loan> findByCustomerCustomerId(Long customerId);

	public List<Loan> findByLoanStatus(LoanStatus loanStatus);

	public List<Loan> findByLoanType(LoanType loanType);

	public List<Loan> findAll();
}
