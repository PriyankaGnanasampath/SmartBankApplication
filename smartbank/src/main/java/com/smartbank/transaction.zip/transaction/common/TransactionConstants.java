package com.smartbank.transaction.common;

public class TransactionConstants {
public static final String TRANSACTION_REFERENCE_NUMBER="TRANSACTION_REFERENCE_NUMBER";


}
